﻿namespace BussinessModels.Models.CompanyModel
{
    public class RegisteredUsersDetailsDTO
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
    }
}
