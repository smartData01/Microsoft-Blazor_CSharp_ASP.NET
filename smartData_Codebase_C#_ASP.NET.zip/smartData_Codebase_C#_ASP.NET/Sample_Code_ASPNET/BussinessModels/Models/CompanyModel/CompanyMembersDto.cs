﻿namespace BussinessModels.Models.CompanyModel
{
    public class CompanyMembersDto
    {
        public int MemberId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
    }
}
