﻿namespace BussinessModels.Models.CompanyModel
{
    public class PaymentTermsDTO
    {
        public int PaymentTermId { get; set; }
        public string PaymentTermName { get; set; }
    }
}
