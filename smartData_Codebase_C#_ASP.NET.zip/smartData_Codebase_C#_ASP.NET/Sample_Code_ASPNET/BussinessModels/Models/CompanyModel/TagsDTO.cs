﻿namespace BussinessModels.Models.CompanyModel
{
    public class TagsDTO
    {
        public string TagName { get; set; }
        public int TagsMasterId { get; set; }

    }
}
