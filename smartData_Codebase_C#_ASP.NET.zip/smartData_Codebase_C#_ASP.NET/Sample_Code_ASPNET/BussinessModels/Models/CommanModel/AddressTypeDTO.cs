﻿namespace BussinessModels.Models.CompanyModel
{
    public class AddressTypeDTO
    {
        public int AddressTypeId { get; set; }
        public string AddressTypeName { get; set; }
    }
}
