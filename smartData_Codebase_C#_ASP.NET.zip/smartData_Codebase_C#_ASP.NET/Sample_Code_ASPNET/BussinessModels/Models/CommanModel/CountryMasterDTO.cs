﻿namespace BussinessModels.Models.CompanyModel
{
    public class CountryMasterDTO
    {
        public int CountryMasterId { get; set; }
        public string CountryName { get; set; }
    }
}
