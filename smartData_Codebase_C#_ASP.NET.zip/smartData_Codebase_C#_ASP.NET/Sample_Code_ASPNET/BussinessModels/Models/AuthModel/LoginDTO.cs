﻿namespace BussinessModels.Models.AuthModel
{
    public class LoginDTO
    {
        public string EmailId { get; set;}
        public string Password { get; set;}
    }
}
