﻿namespace PCPUI.Shared.Services.Accounts
{
    public class DPOServices : AbstractCrudService<AccountDPO>
    {
        private readonly PCPAPIClient DPOApi;

        public DPOServices(PCPAPIClient DPOApi, IErrorHandler ErrorHandler)
            : base(ErrorHandler, new string[] { "AccountMemberId" })
        {
            this.DPOApi = DPOApi;
        }

        public override AccountDPO GetEmptyRecord()
        {
            AccountDPO dpo = new AccountDPO();
            dpo.ContactDetails = new List<ContactDetails>()
            {
                new ContactDetails
                {
                    Data = string.Empty,
                }
            };
            return dpo;
        }

        protected override async Task<AccountDPO> CreateAsyncInternal(AccountDPO request)
        {
            return await DPOApi.CreateAccountDPOAsync(request);
        }

        protected override async Task<Wrapper.Void> DeleteAsyncInternal(string id)
        {
            await DPOApi.DeleteAccountDPOAsync(id);
            return new Wrapper.Void();
        }

        protected override async Task<List<AccountDPO>> GetAllAsyncInternal()
        {
            try
            {
                var response = await DPOApi.GetAccountDPOsAsync();
                return response.ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        protected override async Task<AccountDPO> GetByIdAsyncInternal(string id)
        {
            return await DPOApi.GetAccountDPOAsync(id);
        }

        protected override async Task<AccountDPO> UpdateAsyncInternal(string id, AccountDPO request)
        {
            try
            {
                var response = await DPOApi.UpdateAccountDPOAsync(id, request);
                return response;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }
    }
}
