﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims;

namespace PCPUI.Shared.Services.Authentication
{
    public class AuthenticationService : IAuthenticationService
    {
        private readonly PCPAPIClient PCPAPIClient;
        private readonly IErrorHandler ErrorHandler;
        private readonly UserService UsersService;
        private readonly AuthenticationStateProvider AuthenticationStateProvider;
        private readonly SignOutSessionStateManager SignOutManager;
        private readonly NavigationManager NavigationManager;

        private User _sessionUser;

        public User SessionUser { get => _sessionUser; }

        public event EventHandler SessionUserUpdated;

        public AuthenticationService(
            PCPAPIClient PCPAPIClient, 
            IErrorHandler ErrorHandler, 
            UserService UsersService, 
            AuthenticationStateProvider AuthenticationStateProvider, 
            SignOutSessionStateManager SignOutManager, 
            NavigationManager NavigationManager)
        {
            this.PCPAPIClient = PCPAPIClient;
            this.ErrorHandler = ErrorHandler;
            this.UsersService = UsersService;
            this.AuthenticationStateProvider = AuthenticationStateProvider;
            this.SignOutManager = SignOutManager;
            this.NavigationManager = NavigationManager;
        }

        public async Task<PCPAPI.User> GetSessionUser()
        {
            var authState = await AuthenticationStateProvider.GetAuthenticationStateAsync();
            var user = authState.User;

            if (user.Identity.IsAuthenticated)
            {
                IEnumerable<Claim> _claims = user.Claims;
                string sessionUserId = _claims.FirstOrDefault(c => c.Type == "sub")?.Value;
                if (sessionUserId != null)
                {
                    var response = await UsersService.GetByIdAsync(sessionUserId);
                    if (response.Succeeded)
                    {
                        return response.Data;
                    }
                }
            }
            return null;
        }

        public async Task<User> RefreshSessionUserAsync()
        {
            _sessionUser = await GetSessionUser();
            OnSessionUserUpdatedEvent();
            return _sessionUser;
        }

        protected virtual void OnSessionUserUpdatedEvent()
        {
            EventHandler handler = SessionUserUpdated;
            handler?.Invoke(this, EventArgs.Empty);
        }

        public async Task ResetPasswordAsync(string userId)
        {
            await UsersService.ResetPasswordAsync(userId);
        }


        public async Task Logout()
        {
            await SignOutManager.SetSignOutState();
            NavigationManager.NavigateTo("authentication/logout");
        }

        public async Task<bool> IsUserAuthenticatedAsync()
        {
            var authState = await AuthenticationStateProvider.GetAuthenticationStateAsync();
            var user = authState.User;
            return user.Identity.IsAuthenticated;
        }

        public async Task<bool> IsUserEmailVerified()
        {
            var authState = await AuthenticationStateProvider.GetAuthenticationStateAsync();
            var user = authState.User;
            IEnumerable<Claim> _claims = user.Claims;
            var emailVerfied = _claims.FirstOrDefault(c => c.Type == "email_verified")?.Value;
            var isVerifiedEmail = bool.Parse(emailVerfied);
            return isVerifiedEmail;
            //return false;
        }

        public async Task<string> GetUserEmail()
        {
            var authState = await AuthenticationStateProvider.GetAuthenticationStateAsync();
            var user = authState.User;
            IEnumerable<Claim> _claims = user.Claims;
            string email = _claims.FirstOrDefault(c => c.Type == "email")?.Value;
            return email;
        }

        public async Task<string> GetUserID()
        {
            var authState = await AuthenticationStateProvider.GetAuthenticationStateAsync();
            var user = authState.User;
            IEnumerable<Claim> _claims = user.Claims;
            string userID = _claims.FirstOrDefault(c => c.Type == "sub")?.Value;
            return userID;
        }

    }
}
